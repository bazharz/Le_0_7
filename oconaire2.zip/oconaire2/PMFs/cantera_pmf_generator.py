import cantera as ct
import argparse
import csv
import os
import numpy as np


mechanism='oconaire'

width = 1  # m
loglevel = 1  # amount of diagnostic output (0 to 8)

phi = 0.6
atm = 1
p = atm*ct.one_atm
T = 298
dat_file = 'pmf-'+mechanism+'-phi'+str(phi)+'-T'+str(T)+'-p'+str(atm)+'.dat'

reactants = {'H2':1, 'O2':(1/phi)*0.5, 'N2':(0.79/(0.21*phi))*0.5}

gas = ct.Solution(mechanism+'.yaml')
gas.TPX = T, p, reactants

f = ct.FreeFlame(gas,width=width)
f.max_grid_points=1000 
f.max_time_step_count=5000
f.set_refine_criteria(ratio=5, slope=0.02, curve=0.02)
f.transport_model = 'Mix'
f.solve(loglevel=loglevel, auto=True)
print('flame speed = '+str(f.velocity[0]*100)+'cm/s')
tt = (f.T[-1]-f.T[0])/np.amax(np.gradient(f.T,f.grid))
print('thermal thickness = '+str(tt))
#find flamepoint
midtemp = (f.T[-1]+f.T[0])/2.0

flamepoint = f.grid[np.argmin(abs(f.T-midtemp))]

# Always save with Mole Fractions of all species and CGS units
nz = f.flame.n_points
with open(dat_file, "w") as outfile:
    writer = csv.writer(
        outfile, delimiter=" ", quotechar=" ", quoting=csv.QUOTE_MINIMAL
    )
    writer.writerow(
        ['VARIABLES = "X" "temp" "u" "rho"']
        + ['"X_' + x + '"' for x in gas.species_names]
    )
    writer.writerow(["ZONE I=" + str(nz) + " FORMAT=POINT" + " SPECFORMAT=MOLE"])
    for kk in range(len(f.grid)):
        f.set_gas_state(kk)
        writer.writerow(
            [(f.grid[kk]-flamepoint) * 1e2, gas.T, f.velocity[kk], gas.density * 1e-3]
            + list(gas.X)
        )
